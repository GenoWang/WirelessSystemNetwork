cd aodv-uu
make clean
cd ..
make
